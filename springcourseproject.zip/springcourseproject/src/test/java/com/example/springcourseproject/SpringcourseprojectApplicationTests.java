package com.example.springcourseproject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringcourseprojectApplicationTests {

	@Test
	void contextLoads() {
	}

}
